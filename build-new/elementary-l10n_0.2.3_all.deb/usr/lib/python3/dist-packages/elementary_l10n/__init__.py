"""elementary OS translation status viewer."""
__version__ = "0.1.0"
